package srvftp;

// Imports necesarios para usar RabbitMQ
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP;

// Imports necesarios para usar RMI
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.RemoteException;

// Import necesario para leer fichero 
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.BufferedReader;

// Import necesarios para obtener la fecha y hora actuales
import java.util.Date;

// Import para trabajar con listas
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

// Cola bloqueante para comunicar el hilo ReceptorConsultas y los hilos Worker
import java.util.concurrent.ArrayBlockingQueue;

// Import necesario para acceder a los métodos del cliente
import cliente.ClienteInterface;

// ===================================================================
// Las dos clases siguientes son hilos que se ejecutarán de forma concurrente
//
// - ReceptorConsultas es el hilo que espera mensajes de RabbitMQ e introduce
//   los mensajes recibidos en la cola interna (cola bloqueante)
// - Worker son los hilos que leen de la cola interna, resuelven las peticiones.

// Clase ReceptorConsultas. Recibe mensajes por RabbitMQ, y los mete en la cola bloqueante 
// de eventos para que sean procesados por los hilos Worker
class ReceptorConsultas extends Thread {
    private final static String NOMBRE_COLA_RABBIT = "cola_pet_ftp"; // A RELLENAR (cambiar nombre)
    private ArrayBlockingQueue<String> qrequest; // Cola bloqueante para comunicar con los workers

    // El constructor recibe una referencia a la cola bloqueante
    // que le permiten comunicarse con los hilos Worker
    public ReceptorConsultas(ArrayBlockingQueue<String> qrequest) {
        this.qrequest = qrequest;
    }

    // La función run es la que se ejecuta al poner en marcha el hilo
    public void run() {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        try {
            // Conectar con rabbitMQ
            // A RELLENAR:
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();

            // Espera por peticiones en la cola rabbitMQ
            Consumer consumer = new DefaultConsumer(channel) {
                @Override
                public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties,
                        byte[] body)
                        throws IOException {
                    // ************************************************************
                    // Recepción y manejo del mensaje que llega por RabbitMQ
                    // ************************************************************

                    // Convertir en cadena el mensaje recibido y meterlo en la cola bloqueante
                    String msg = new String(body, "UTF-8");
                    System.out.println("ReceptorConsultas: Recibida consulta = " + msg);

                    // A RELLENAR:
                    try {
                        qrequest.put(msg);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        System.exit(10);
                    }

                }
            };
            System.out.println("ReceptorConsultas. Esperando llegada de peticiones FTP");
            // Arrancar la espera de mensajes en la cola RabbitMQ
            // A RELLENAR:
            channel.queueDeclare(NOMBRE_COLA_RABBIT, false, false, false, null);
            channel.basicConsume(NOMBRE_COLA_RABBIT, true, consumer);

        } catch (Exception e) { // No manejamos excepciones, simplemente abortamos
            e.printStackTrace();
            System.exit(7);
        }
    }
}

// Clase Worker espera en una cola bloqueante a que el hilo ReceptorConsultas le
// envíe una consulta para procesarla.

class Worker extends Thread {

    private ArrayBlockingQueue<String> cola; // Cola bloqueante para comunicarse con hilo ReceptorConsultas
    private FileSystemActions fsa; // Objeto que permite realizar acciones sobre ficheros y carpetas
    private String droot; // Directorio raíz desde el que se van a servir las peticiones de descarga
    private String nflog; // Nombre del fichero de log

    // El constructor recibe una referencia al objeto
    // que contabiliza las consultas recibidas y la cola

    public Worker(ArrayBlockingQueue<String> cola, String droot, String nomflog) {
        this.cola = cola;
        this.droot = droot;
        this.nflog = nomflog;
        this.fsa = new FileSystemActions();
    }

    // El método run es el que se ejecuta al arrancar el hilo
    public void run() {

        String cadena = "";

        try {
            while (true) { // Bucle infinito
                // Esperar consulta en la cola bloqueante
                // A RELLENAR:
                String peticion = cola.take();

                // Procesar consulta separando sus campos por el caracter ","
                String partes[] = peticion.split(" ");
                if (partes.length < 3 || partes.length > 4) {
                    System.out.println(
                            String.format("Ignorada peticion por no tener el formato esperado '%s'", peticion));
                } else {
                    try {

                        // Localizar al cliente RMI al que hay que devolver la respuesta. Su nombre está
                        // en la primera parte del mensaje recibido desde la cola
                        // A RELLENAR:
                        ClienteInterface cliente = null;
                        int reintentos = 5;
                        while (reintentos-- > 0) {
                            try {
                                cliente = (ClienteInterface) Naming.lookup(partes[0]);
                                break;
                            } catch (java.rmi.NotBoundException e) {
                                Thread.sleep(500);
                            }
                        }
                        if (cliente == null) continue;
                        
                        if (partes[1].equals("ISFILE")) {
                            // Comprobar si el fichero existe
                            if (fsa.fileExists(droot + "/" + partes[2])) {
                                // A RELLENAR: (enviar respuesta)
                                cliente.setIsFile(true);
                            } else {
                                // A RELLENAR: (enviar respuesta)
                                cliente.setIsFile(false);
                            }   
                        } else if (partes[1].equals("ISREADABLE")) {
                            // Comprobar si el fichero es legible
                            if (fsa.fileIsReadable(droot + "/" + partes[2])) {
                                // A RELLENAR: (enviar respuesta)
                                cliente.setIsReadable(true);
                            } else {
                                // A RELLENAR: (enviar respuesta)
                                cliente.setIsReadable(false);
                            }
                        } else if (partes[1].equals("GETNUMLINES")) {
                            // Enviar el número de líneas del fichero
                            // A RELLENAR:
                            int numLines = fsa.getNumLines(droot + "/" + partes[2]);
                            cliente.setNumLines(numLines);
                        } else if (partes[1].equals("GETLINE")) {
                            int numLine = Integer.parseInt(partes[3]);
                            // Enviar la línea del fichero
                            // A RELLENAR:
                            String lineaFichero = fsa.getLine(droot + "/" + partes[2], numLine);
                            cliente.setLine(lineaFichero);
                        }
                    } catch (Exception e) {
                        // Cualquier excepción simplemente se imprime
                        System.out.println("Error en SrvFTP al devolver respuesta al cliente" + e.getMessage());
                        e.printStackTrace();
                    }

                    // Registrar la petición en el fichero de log
                    Date fecha = new Date();
                    try {
                        String linea;
                        // Preparar la línea a volcar
                        // A RELLENAR:
                        linea = fecha.toString() + " - " + peticion + "\n";
                        BufferedWriter bw = new BufferedWriter(new FileWriter(nflog, true));
                        bw.write(linea);
                        bw.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(8);
        }
    }
}

// Clase principal que instancia el hilo de recepción y los hilos worker y los
// arranca
public class SrvFTP {

    public static void main(String[] argv) throws Exception {

        String nameflog = null; // Para registrar las consultas procesadas
        FileSystemActions fsa = new FileSystemActions();

        // Los valores de estas variables se leen de línea de comandos
        int tam_cola = 0; // Tamaño de la array blocking queue
        int num_workers = 0; // Numero de hilos trabajadores

        // Cola interna de sincronización entre el hilo ReceptorConsultas y los Worker
        ArrayBlockingQueue<String> cola_interna;

        // Variable que representa el hilo receptor de eventos
        ReceptorConsultas receptor_consultas;
        // Variable que representa a los hilos trabajadores
        Worker[] workers;

        // Lectura de la línea de comandos
        //
        if (argv.length < 4) {
            System.out.println("Uso: SrvFTP <tam_cola> <num_workers> <document_root> <fichero_log>");
            System.exit(1);
        }
        try {
            tam_cola = Integer.parseInt(argv[0]);
            num_workers = Integer.parseInt(argv[1]);
        } catch (NumberFormatException e) {
            System.out.println("Los argumentos tam_cola y numworkers deben ser enteros");
            System.exit(2);
        }

        if (tam_cola < 1) {
            System.out.println("tam_cola debe ser un valor >=1");
            System.exit(5);
        }
        if (num_workers < 1) {
            System.out.println("num_workers debe ser un valor >=1");
            System.exit(6);
        }

        if (!fsa.directoryExists(argv[2])) {
            System.out.println("El directorio " + argv[2] + " no existe");
            System.exit(7);
        }
        nameflog = argv[3];

        // Primero se crea la cola interna de sincronización entre hilos
        // A RELLENAR:
        cola_interna = new ArrayBlockingQueue<>(tam_cola);

        // Crear los hilos Worker y arrancarlos
        workers = new Worker[num_workers];
        // A RELLENAR:
        for (int i = 0; i < num_workers; i++) {
            workers[i] = new Worker(cola_interna, argv[2], nameflog);
            workers[i].start();
        }

        // Crear el hilo receptor de consultas y arrancarlo
        receptor_consultas = new ReceptorConsultas(cola_interna);
        receptor_consultas.start();

        // Esperamos a que finalice el hilo receptor de eventos (nunca finalizará, hay
        // que parar con Ctrl+C)
        receptor_consultas.join();
    }
}
